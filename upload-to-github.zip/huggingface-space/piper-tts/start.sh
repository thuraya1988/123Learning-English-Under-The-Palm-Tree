#!/usr/bin/env bash
set -euo pipefail

VOICES_DIR="${VOICES_DIR:-/voices}"
HF_BASE="https://huggingface.co/rhasspy/piper-voices/resolve/v1.0.0"

mkdir -p "${VOICES_DIR}"

# Upgraded from en_GB-alan-LOW to en_GB-alan-MEDIUM (same British voice,
# clearer/less robotic audio). Fetched straight from the upstream Piper
# voices repo so the 60MB+ model files never need to live in her GitHub
# repo at all.
declare -A VOICE_URLS=(
    ["en_GB-alan-medium.onnx"]="${HF_BASE}/en/en_GB/alan/medium/en_GB-alan-medium.onnx"
    ["en_GB-alan-medium.onnx.json"]="${HF_BASE}/en/en_GB/alan/medium/en_GB-alan-medium.onnx.json"
    ["ar_JO-kareem-medium.onnx"]="${HF_BASE}/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx"
    ["ar_JO-kareem-medium.onnx.json"]="${HF_BASE}/ar/ar_JO/kareem/medium/ar_JO-kareem-medium.onnx.json"
)

for f in "${!VOICE_URLS[@]}"; do
    out="${VOICES_DIR}/${f}"
    if [[ ! -s "${out}" ]]; then
        echo "Downloading ${f}..."
        curl -fsSL "${VOICE_URLS[$f]}" -o "${out}"
    fi
done

echo "Voices ready in ${VOICES_DIR}:"
ls -lh "${VOICES_DIR}"

exec uvicorn app:app --host 0.0.0.0 --port "${PORT:-7860}"
